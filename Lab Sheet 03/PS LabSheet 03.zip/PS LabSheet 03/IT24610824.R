student_data <- read.csv("Exercise.csv", header = TRUE)
fix(student_data)  

summary(student_data$X1)
hist(student_data$X1, main = "Histogram of Age", xlab = "Age", ylab = "Frequency")

gender_freq <- table(student_data$X2)
barplot(gender_freq, main = "Bar Chart of Gender", xlab = "Gender", ylab = "Frequency")
print(gender_freq)  

boxplot(X1 ~ X3, data = student_data, 
        main = "Age Distribution by Accommodation", 
        xlab = "Accommodation Type", 
        ylab = "Age")

