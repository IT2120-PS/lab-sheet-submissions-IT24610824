vec <- 1:15
count_divisible_by_3 <- sum(vec %% 3 == 0)
print(count_divisible_by_3)

vec <- c(5, 9, 3, 7, 2)
max_val <- -Inf
max_index <- 0

for (i in 1:length(vec)) {
  if (vec[i] > max_val) {
    max_val <- vec[i]
    max_index <- i
  }
}
print(max_index)

vec <- c(5, 9, 3, 7, 2)
max_index <- which.max(vec)
print(max_index)